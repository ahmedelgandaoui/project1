var toggle = document.getElementById('toggle');
var close = document.getElementById('close');
var resNavbar = document.getElementById('res-navbar')

toggle.addEventListener('click', () => {
    resNavbar.style.display = 'block'
});
close.addEventListener('click', () => {
    resNavbar.style.display = 'none'
});

var topNav = document.querySelector('.navbar .top-navbar');
var mainNav = document.querySelector('.navbar .main-navbar');
var mainLogo = document.querySelector('.main-logo .logo');

window.onscroll = () => {
    if (scrollY > 90) {
        topNav.classList.add('close');
        mainNav.classList.add('sticky');

        mainLogo.src = './Images/white-logo.png';
    } else {
        topNav.classList.remove('close');
        mainNav.classList.remove('sticky');
        mainLogo.src = './Images/logo.png';
    }
}


var swiperHero = new Swiper(".heroSlider", {
    grabCursor: true,
    effect: "creative",
    loop: true,
    scrollbar: {
        el: ".swiper-scrollbar",
    },
    navigation: {
        nextEl: ".swiper-button-next",
        prevEl: ".swiper-button-prev",
    },
    creativeEffect: {
        prev: {
            shadow: true,
            translate: ["-120%", 0, -500],
        },
        next: {
            shadow: true,
            translate: ["120%", 0, -500],
        },
    },
});

var swiperCheckout = new Swiper(".checkoutSlider", {
    slidesPerView: 3,
    spaceBetween: 30,
    grabCursor: true,
    pagination: {
        el: ".swiper-pagination",
        clickable: true,
    },
    breakpoints: {
        0: {
            slidesPerView: 1,
            spaceBetween: 10,
        },
        600: {
            slidesPerView: 2,
            spaceBetween: 20,
        },
        992: {
            slidesPerView: 3,
            spaceBetween: 50,
        },
    },
});

var swiperBlog = new Swiper(".blogSlider", {
    slidesPerView: 3,
    spaceBetween: 30,
    autoplay: {
        delay: 2500,
        disableOnInteraction: false,
    },
    pagination: {
        el: ".swiper-pagination",
        clickable: true,
    },
    navigation: {
        nextEl: ".swiper-button-next",
        prevEl: ".swiper-button-prev",
    },
    breakpoints: {
        0: {
            slidesPerView: 1,
            spaceBetween: 10,
        },
        600: {
            slidesPerView: 2,
            spaceBetween: 20,
        },
        992: {
            slidesPerView: 3,
            spaceBetween: 50,
        },
    },
});

var swiperTestimonial = new Swiper(".testiSlider", {
    direction: "vertical",
    loop: true,
    slidesPerView: 1,
    spaceBetween: 40,
    mousewheel: true,
    pagination: {
        el: ".swiper-pagination",
        clickable: true,
    },
    navigation: {
        nextEl: ".swiper-button-next",
        prevEl: ".swiper-button-prev",
    },

});